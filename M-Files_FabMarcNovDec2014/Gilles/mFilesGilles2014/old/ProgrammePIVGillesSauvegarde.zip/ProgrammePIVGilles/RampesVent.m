fiche=fopen('E:\data\RampeDeVent\LC.txt','r') ;
LC1=fscanf(fiche,'%g %g',[2 inf]);
LC1=LC1';
fclose(fiche);

fiche=fopen('E:\data\RampeDeVent\LC2.txt','r') ;
LC2=fscanf(fiche,'%g %g',[2 inf]);
LC2=LC2';
fclose(fiche);

fiche=fopen('E:\data\RampeDeVent\LC3.txt','r') ;
LC3=fscanf(fiche,'%g %g',[2 inf]);
LC3=LC3';
fclose(fiche);

fiche=fopen('E:\data\RampeDeVent\LC4.txt','r') ;
LC4=fscanf(fiche,'%g %g',[2 inf]);
LC4=LC4';
fclose(fiche);


figure, plot(LC1(:,1),LC1(:,2))
hold on,  plot(LC2(:,1),LC2(:,2),'r'), plot(LC3(:,1),LC3(:,2),'k'), plot(LC4(:,1),LC4(:,2),'c')

% smo=10000000000;
% figure, plot(LC1(:,1),smoothn(LC1(:,2),smo))
% hold on,  plot(LC2(:,1),smoothn(LC2(:,2),smo),'r'), plot(LC3(:,1),smoothn(LC3(:,2),smo),'k'), plot(LC4(:,1),smoothn(LC4(:,2),smo),'c')




